//
//  ViewController.swift
//  WebCrawling_Practice
//
//  Created by 김승현 on 2022/05/16.
//

import UIKit
import SwiftSoup

class ViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        crawlWebSite()
    }

    func crawlWebSite() {
        let url = "https://www.daangn.com/search/%EC%88%98%EC%9C%A0%20%EB%83%89%EC%9E%A5%EA%B3%A0"
        guard let myUrl = URL(string: url) else { return }
        do {
            let html = try String(contentsOf: myUrl, encoding: .utf8)
            let doc: Document = try SwiftSoup.parse(html)
            
            let headerTitle = try doc.title()
            print(headerTitle)
            
            let titleOfItem: Elements = try doc.select(".article-title")
            for i in titleOfItem {
                print("title: ", try i.text())
            }
            
            //let price: Elements = try doc.select(".result").select("article-price")
            let price: Elements = try doc.select(".article-price")
            for i in price {
                print("price: ", try i.text())
            }
            print(price.count)
            
        } catch Exception.Error(let type, let message){
            print("Message: \(message)")
        } catch {
            print("error")
        }
        
        
    }

}

